const settings = {
  packname: 'Knight',
  author: 'Bot',
  botName: "Knight Bot",
  botOwner: 'Professor', // Your name
  ownerNumber: '917023951514', //Your number
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "1.0.0",
};

module.exports = settings;
